<!DOCTYPE html>
<html>
<head>
    <title>Manager Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 18px;
            background-image: url('cus_pic.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 50px;
            background-color: #f2f2f2;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            display: block;
            margin-top: 20px;
            width: 100%;
            cursor: pointer;
        }

        p {
            text-align: center;
            margin-top: 10px;
        }

        a {
            color: #4CAF50;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<nav>
    </ul>
        <li><h9>~  Kaira  Supermarket  Management  System</h8></li>
	</ul>
</nav>
    </div>
    <br>
    <div class="container">
        <h2>Manager Login</h2>
        <form action="m_login.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <br><br>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <br><br>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
