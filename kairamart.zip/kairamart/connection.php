<?php
$servername = "localhost:3307";
$username = "karan";
$password = "";
$dbname = "kairamart";

$connection = mysqli_connect($servername, $username, $password, $dbname);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";
mysqli_close($connection);
?>
