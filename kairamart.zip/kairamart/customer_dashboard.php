<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "kairamart"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process add to cart functionality
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["addToCart"])) {
    $productId = $_POST["productId"];
    $quantity = $_POST["quantity"];

    // Check if the product is already in the cart
    $cartCheck_sql = "SELECT * FROM cart WHERE p_id = '$productId'";
    $cartCheck_result = $conn->query($cartCheck_sql);

    if ($cartCheck_result->num_rows > 0) {
        // Product already exists in the cart, update the quantity
        $cartCheck_row = $cartCheck_result->fetch_assoc();
        $existingQuantity = $cartCheck_row["quantity"];
        $newQuantity = $existingQuantity + $quantity;
        $cartId = $cartCheck_row["cart_no"]; // Add this line to get the cart number

        // Update the quantity in the cart
        $updateQuantity_sql = "UPDATE cart SET quantity = '$newQuantity' WHERE p_id = '$productId'";
        if ($conn->query($updateQuantity_sql) === TRUE) {
            echo "<script>alert('Product quantity updated in the Cart No: $cartId');</script>";
        } else {
            echo "<script>alert('Error updating product quantity: " . $conn->error . "');</script>";
        }
    } else {
        // Retrieve product details
        $product_sql = "SELECT * FROM product WHERE p_id = '$productId'";
        $product_result = $conn->query($product_sql);

        if ($product_result->num_rows > 0) {
            $product_row = $product_result->fetch_assoc();

            $productName = $product_row["p_name"];
            $unitPrice = $product_row["unit_price"];

            // Create a new cart and get the auto-incremented cart number
            $createCart_sql = "INSERT INTO cart (p_id, p_name, quantity, unit_price) VALUES ('$productId', '$productName', '$quantity', '$unitPrice')";
            if ($conn->query($createCart_sql) === TRUE) {
                $cart_no = $conn->insert_id; // Get the auto-incremented cart number
                echo "<script>alert('Product added to cart successfully. Cart No: $cart_no');</script>";
            } else {
                echo "<script>alert('Error creating new cart: " . $conn->error . "');</script>";
            }
        }
    }
}

// Retrieve product list from the database
$product_sql = "SELECT * FROM product";
$product_result = $conn->query($product_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Customer Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 18px;
            background-image: url('cus_dashboard.webp');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f2f2f2;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        h3 {
            text-align: center;
            color: #4CAF50;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .add-to-cart-form {
            display: flex;
            align-items: center;
        }

        .quantity-input {
            width: 50px;
            margin-right: 10px;
            padding: 5px;
        }

        .add-to-cart-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .add-to-cart-button:hover {
            background-color: #45a049;
        }

        .cart-message {
            text-align: center;
            margin-top: 20px;
            color: #4CAF50;
            font-weight: bold;
        }

        .generate-bill-button {
            background-color: #fc9d03;
            color: black;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            display: block;
            margin: 20px auto;
            cursor: pointer;
        }

        .generate-bill-button:hover {
            background-color: #fc7703;
        }
    </style>
    <script>
        function confirmGenerateBill() {
            var productCount = <?php echo $product_result->num_rows; ?>;
            if (productCount === 0) {
                alert("No Products in the cart. Add products first.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
<nav>
    </ul>
        <li><h9>~  Kaira  Supermarket  Management  System</h8></li>
	</ul>
</nav>
    </div>
    <br>
    <div class="container">
        <h3>Welcome to the Customer Dashboard</h3>

        <?php if (isset($cartMessage)) : ?>
            <div class="cart-message"><?php echo $cartMessage; ?></div>
        <?php endif; ?>

        <table>
            <tr>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            <?php
            if ($product_result->num_rows > 0) {
                $counter = 0;
                while ($product_row = $product_result->fetch_assoc()) {
                    if ($counter % 2 == 0) {
                        echo "<tr>";
                    }
                    $productId = $product_row["p_id"];
                    $productName = $product_row["p_name"];
                    $productPrice = $product_row["unit_price"];
                    $productImage = $product_row["image_url"];
                    ?>
                    <td>
                        <div class="product">
                            <div class="product-image">
                                <img src="images/<?php echo $productImage; ?>" alt="<?php echo $productName; ?>" style="max-width: 100px; max-height: 100px;">
                            </div>
                            <div class="product-details">
                            <div class="product-price">&#8377;<?php echo $productPrice; ?></div>
                            <form class="add-to-cart-form" action="" method="POST">
                                <input class="quantity-input" type="number" name="quantity" value="1" min="1">
                                <input type="hidden" name="productId" value="<?php echo $productId; ?>">
                                <input type="submit" name="addToCart" class="add-to-cart-button" value="Add to Cart">
                            </form>
                        </div>

                        </div>
                    </td>
                    <?php
                    if ($counter % 2 != 0) {
                        echo "</tr>";
                    }
                    $counter++;
                }
                // If there is an odd number of products, close the last row
                if ($counter % 2 != 0) {
                    echo "<td></td></tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No products available.</td></tr>";
            }
            ?>
        </table>

        <form action="bill.php" method="POST" onsubmit="return confirmGenerateBill();">
            <input type="submit" name="generateBill" class="generate-bill-button" value="Generate Bill">
        </form>
    </div>
</body>
</html>
