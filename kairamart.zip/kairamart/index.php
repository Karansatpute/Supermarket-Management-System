<!DOCTYPE html>
<html>
<head>
    <title>Supermarket Management System - Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 1px;
            font-size: 18px;
            background-image: url('super2.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        
        .container {
            max-width: 330px;
            margin: 0 auto;
            padding: 0.5px;
        }

        h2 {
            text-align: center;
        }

        .btn {
            display: inline-block;
            background-color: #57cf3c;
            color: black;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            display: block;
            margin-bottom: 20px;
            border: 1px solid grey;
        }

        .btn:hover {
            background-color: #3c9f2d; /* Update hover background color */
        }
    </style>
</head>
<body>
<center>
   <br>
    <h1 style="font-size: 46px; color: black; text-shadow: 5px 5px 5px white;"><b>Welcome to the Kaira Mart</b></h1>
        
    <div class="container">
        <a class="btn" href="customer_login.php">Customer Login</a>
        <a class="btn" href="manager_login.php">Manager Login</a>
        <a class="btn" href="create_account.php">Create Customer Account</a>
    </div>
</center>
</body>
</html>
