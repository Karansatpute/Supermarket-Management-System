<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your MySQL password
$dbname = "kairamart"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle adding a new staff member
if (isset($_POST['addStaff'])) {
    $empId = $_POST['empId'];
    $empName = $_POST['empName'];
    $position = $_POST['position'];
    $floor = $_POST['floor'];
    $salary = $_POST['salary'];

    $addStaff_sql = "INSERT INTO staff (emp_id, emp_name, position, floor, salary)
                     VALUES ('$empId', '$empName', '$position', '$floor', '$salary')";

    if ($conn->query($addStaff_sql) === true) {
        // Staff member added successfully, redirect to the dashboard
        header("Location: staff_dashboard.php");
        exit();
    } else {
        echo "Error: " . $addStaff_sql . "<br>" . $conn->error;
    }
}

// Handle deleting a staff member
if (isset($_POST['deleteStaff'])) {
    $empId = $_POST['empId'];

    $deleteStaff_sql = "DELETE FROM staff WHERE emp_id = '$empId'";

    if ($conn->query($deleteStaff_sql) === true) {
        // Staff member deleted successfully, refresh the page
        header("Location: staff_dashboard.php");
        exit();
    } else {
        echo "Error: " . $deleteStaff_sql . "<br>" . $conn->error;
    }
}
// Handle updating a staff member
if (isset($_POST['updateStaff'])) {
    $empId = $_POST['empId'];
    $empName = $_POST['empName'];
    $position = $_POST['position'];
    $floor = $_POST['floor'];
    $salary = $_POST['salary'];

    $updateStaff_sql = "UPDATE staff SET emp_name = '$empName', position = '$position', floor = '$floor', salary = '$salary' WHERE emp_id = '$empId'";

    if ($conn->query($updateStaff_sql) === true) {
        // Staff member updated successfully, refresh the page
        header("Location: staff_dashboard.php");
        exit();
    } else {
        echo "Error: " . $updateStaff_sql . "<br>" . $conn->error;
    }
}
// Retrieve staff members from the database
$staffMembers_sql = "SELECT * FROM staff";
$staffMembers_result = $conn->query($staffMembers_sql);

// Logout functionality
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["logout"])) {
    session_start();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 18px;
            background-image: url('staff_dash.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        h3 {
            text-align: center;
            color: #4CAF50;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1.4px solid black;
        }

        .add-staff-form {
            margin-top: 20px;
        }

        .form-field {
            margin-bottom: 10px;
        }

        .add-staff-button, .update-staff-button {
            background-color: #0787f0;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .add-staff-button:hover, .update-staff-button:hover {
            background-color: #076cf0;
        }

        .delete-staff-button {
            background-color: #f44336;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .delete-staff-button:hover {
            background-color: #d32f2f;
        }

        .dialog-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .dialog {
            background-color: white;
            padding: 20px;
            border-radius: 4px;
            max-width: 500px;
        }

        .dialog h4 {
            margin-top: 0;
            color: #4CAF50;
        }

        .dialog .form-field {
            margin-bottom: 10px;
        }

        .dialog .dialog-buttons {
            display: flex;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .dialog .dialog-buttons button {
            margin-left: 10px;
        }

        .logout-button {
            display: block;
            margin: 20px auto;
            background-color: #808080;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #696969;
        }

        .add-staff-button-outside-table {
            background-color: #0787f0;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 10px;
        }

        .add-staff-button-outside-table:hover {
            background-color: #076cf0;
        }
    </style>
</head>
<body>
<nav>
    </ul>
        <li><h9>~  Kaira  Supermarket  Management  System</h8></li>
	</ul>
</nav>
    </div>
    <br>
    <h3>Staff Dashboard</h3>

    <!-- Display the staff members table -->
    <table>
        <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Position</th>
            <th>Floor</th>
            <th>Salary</th>
            <th></th>
        </tr>
        <?php
        if ($staffMembers_result->num_rows > 0) {
            while ($staffMember_row = $staffMembers_result->fetch_assoc()) {
                $empId = $staffMember_row["emp_id"];
                $empName = $staffMember_row["emp_name"];
                $position = $staffMember_row["position"];
                $floor = $staffMember_row["floor"];
                $salary = $staffMember_row["salary"];
                ?>
                <tr>
    <td><?php echo $empId; ?></td>
    <td><?php echo $empName; ?></td>
    <td><?php echo $position; ?></td>
    <td><?php echo $floor; ?></td>
    <td><?php echo $salary; ?></td>
    <td>
        <form method="POST">
            <input type="hidden" name="empId" value="<?php echo $empId; ?>">
            <button class="update-staff-button" onclick="showUpdateDialog('<?php echo $empId; ?>', '<?php echo $empName; ?>', '<?php echo $position; ?>', '<?php echo $floor; ?>', '<?php echo $salary; ?>')">Update</button>
            <input type="submit" name="deleteStaff" class="delete-staff-button" value="Delete" onclick="return confirm('Are you sure you want to delete this staff member?');">
        </form>
    </td>
</tr>

                <?php
            }
        } else {
            echo "<tr><td colspan='6'>No staff members found.</td></tr>";
        }
        ?>
    </table>
        <!-- Update staff member dialog -->
    <div class="dialog-overlay" id="updateDialogOverlay">
        <div class="dialog" id="updateDialog">
            <h4>Update Staff Member</h4>
            <form method="POST" id="updateForm">
                <input type="hidden" name="empId" id="updateEmpId" required>
                <div class="form-field">
                    <label for="updateEmpName">Employee Name:</label>
                    <input type="text" name="empName" id="updateEmpName" required>
                </div>
                <div class="form-field">
                    <label for="updatePosition">Position:</label>
                    <input type="text" name="position" id="updatePosition" required>
                </div>
                <div class="form-field">
                    <label for="updateFloor">Floor:</label>
                    <input type="text" name="floor" id="updateFloor" required>
                </div>
                <div class="form-field">
                    <label for="updateSalary">Salary:</label>
                    <input type="text" name="salary" id="updateSalary" required>
                </div>
                <div class="dialog-buttons">
                    <button type="submit" name="updateStaff" class="update-staff-button">Update</button>
                    <button type="button" onclick="closeUpdateDialog()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add staff member form -->
    <div class="dialog-overlay" id="addDialogOverlay">
        <div class="dialog" id="addDialog">
            <h4>Add Staff Member</h4>
            <form method="POST" id="addForm">
                <div class="form-field">
                    <label for="empId">Employee ID:</label>
                    <input type="text" name="empId" id="addEmpId" required>
                </div>
                <div class="form-field">
                    <label for="empName">Employee Name:</label>
                    <input type="text" name="empName" id="addEmpName" required>
                </div>
                <div class="form-field">
                    <label for="position">Position:</label>
                    <input type="text" name="position" id="addPosition" required>
                </div>
                <div class="form-field">
                    <label for="floor">Floor:</label>
                    <input type="text" name="floor" id="addFloor" required>
                </div>
                <div class="form-field">
                    <label for="salary">Salary:</label>
                    <input type="text" name="salary" id="addSalary" required>
                </div>
                <div class="dialog-buttons">
                    <button type="submit" name="addStaff" class="add-staff-button">Add Staff</button>
                    <button type="button" onclick="closeAddDialog()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    
    <!-- Add staff button -->
    <button class="add-staff-button-outside-table" onclick="showAddDialog()">Add Staff</button>



    <script>
    function showUpdateDialog(empId, empName, salary, position, floor) {
        document.getElementById("updateEmpId").value = empId;
        document.getElementById("updateEmpName").value = empName;
        document.getElementById("updateSalary").value = salary;
        document.getElementById("updatePosition").value = position;
        document.getElementById("updateFloor").value = floor;
        document.getElementById("updateDialogOverlay").style.display = "flex";
        
        // Prevent form submission
        event.preventDefault();
    }

    function closeUpdateDialog() {
        document.getElementById("updateDialogOverlay").style.display = "none";
    }

    function showAddDialog() {
        document.getElementById("addDialogOverlay").style.display = "flex";
    }

    function closeAddDialog() {
        document.getElementById("addDialogOverlay").style.display = "none";
    }
</script>
    <!-- Logout button -->
    <form action="" method="POST">
        <input type="submit" name="logout" class="logout-button" value="Logout">
    </form>
</body>
</html>