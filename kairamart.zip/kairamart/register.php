<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "kairamart"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST["name"];
$address = $_POST["address"];
$mobile_no = $_POST["mobile_no"];
$password = $_POST["password"];

// Check if mobile number already exists
$check_sql = "SELECT * FROM customer WHERE mobile_no = '$mobile_no'";
$check_result = $conn->query($check_sql);
if ($check_result->num_rows > 0) {
    $message = "Error: Mobile number already exists.";
} else {
    // Insert data into the database
    $sql = "INSERT INTO customer (c_name, c_address, mobile_no, password)
            VALUES ('$username', '$address', '$mobile_no', '$password')";
    
    if ($conn->query($sql) === TRUE) {
        $message = "Account created successfully.";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Account Creation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        
        h2 {
            text-align: center;
        }
        
        .message {
            margin-top: 20px;
            text-align: center;
            font-weight: bold;
            color: <?php echo ($message === "Account created successfully.") ? "#006400" : "#FF0000"; ?>;
        }
        
        .back-button {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-button a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #428bca;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .back-button a:hover {
            background-color: #3071a9;
        }
    </style>
</head>
<body>
<nav>
    </ul>
        <li><h9>~  Kaira  Supermarket  Management  System</h8></li>
	</ul>
</nav>
    </div>
    <br>
    <div class="container">
        <h2></h2>
        <div class="message">
            <?php echo $message; ?>
        </div>
        <div class="back-button">
            <a href="index.php">Back to Home Page for Login</a>
        </div>
    </div>
</body>
</html>
