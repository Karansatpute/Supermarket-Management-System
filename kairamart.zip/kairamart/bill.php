<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "kairamart"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the generation of the bill
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["generateBill"])) {
    // Retrieve the products in the cart
    $cartItems_sql = "SELECT * FROM cart";
    $cartItems_result = $conn->query($cartItems_sql);

    if ($cartItems_result->num_rows > 0) {
        $billAmount = 0; // Variable to store the total bill amount

        // Loop through each product in the cart
        while ($cartItem_row = $cartItems_result->fetch_assoc()) {
            $productId = $cartItem_row["p_id"];
            $quantity = $cartItem_row["quantity"];

            // Retrieve the product details
            $product_sql = "SELECT * FROM product WHERE p_id = '$productId'";
            $product_result = $conn->query($product_sql);

            if ($product_result->num_rows > 0) {
                $product_row = $product_result->fetch_assoc();
                $unitPrice = $product_row["unit_price"];

                // Calculate the subtotal for the current product
                $subtotal = $unitPrice * $quantity;

                // Add the subtotal to the total bill amount
                $billAmount += $subtotal;
            }
        }

        // Insert the bill into the database
        $insertBill_sql = "INSERT INTO bill (bill_amount) VALUES ('$billAmount')";
        if ($conn->query($insertBill_sql) === TRUE) {
            $billId = $conn->insert_id; // Get the auto-incremented bill number
            echo "<script>alert('Bill generated successfully. Bill No: $billId');</script>";
        } else {
            echo "<script>alert('Error generating bill: " . $conn->error . "');</script>";
        }

        // Clear the cart by deleting all items
        $clearCart_sql = "DELETE FROM cart";
        if ($conn->query($clearCart_sql) !== TRUE) {
            echo "<script>alert('Error clearing cart: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('No products in the cart.');</script>";
    }
}

// Logout functionality
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["logout"])) {
    session_start();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Bill</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            font-size: 18px;
            background-image: url('bil1_pic.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        nav {
			background-color: #333;
			color: #fff;
			display: flex;
			justify-content: space-between;
			padding: 2px;
			position: fixed;
			top: 0;
			width: 100%;
			z-index: 999;
		}

		nav ul {
			display: flex;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		nav li {
			margin-right: 20px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 4px;
		}
        h3 {
            text-align: center;
            color: #4CAF50;
        }

        .bill-amount {
            text-align: center;
            font-size: 24px;
            margin-top: 50px;
            font-weight: bold;
        }

        .bill-number {
            text-align: center;
            font-size: 20px;
            margin-top: 20px;
        }

        .generate-bill-button {
            display: block;
            margin: 20px auto;
            background-color: #f44336;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .generate-bill-button:hover {
            background-color: #d32f2f;
        }

        .logout-button {
            display: block;
            margin: 20px auto;
            background-color: #808080;
            color: white;
            padding: 8px 16px;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .logout-button:hover {
            background-color: #696969;
        }
    </style>
    <script>
        function showPopup(message) {
            alert(message);
        }
    </script>
</head>
<body>
<nav>
    </ul>
        <li><h9>~  Kaira  Supermarket  Management  System</h8></li>
	</ul>
</nav>
    </div>
    <br>
    <h3>Bill Dashboard</h3>

    <?php if (isset($billId)) : ?>
        <!-- Display the bill number if available -->
        <div class="bill-number"><b>Bill Number: </b><?php echo $billId; ?></div>
    <?php endif; ?>

    <!-- Display the bill amount -->
    <div class="bill-amount">Total Bill Amount: &#8377;<?php echo $billAmount; ?></div>

    <!-- Display popup if there are no products in the cart -->
    <?php if ($cartItems_result->num_rows === 0) : ?>
        <script>
            showPopup("No Products in the Cart");
        </script>
    <?php endif; ?>

    <!-- Logout button -->
    <form action="" method="POST">
        <input type="submit" name="logout" class="logout-button" value="Logout">
    </form>
</body>
</html>
