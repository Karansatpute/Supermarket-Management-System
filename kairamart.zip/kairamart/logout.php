<?php
// Perform any logout-related actions here

// Redirect to the login page or any other desired page
header("Location: customer_login.php");
exit;
?>
