<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = ""; // No password set for XAMPP MySQL
$dbname = "kairamart"; // Name of your database

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$username = $_POST["username"];
$password = $_POST["password"];

// Check if username and password match
$sql = "SELECT * FROM customer WHERE c_name = '$username' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Login successful
    echo '<!DOCTYPE html>
            <html>
            <head>
                <title>Login Successful</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 20px;
                        font-size: 18px;
                        
                    }

                    .container {
                        max-width: 400px;
                        margin: 0 auto;
                        padding: 50px;
                        background-color: #f2f2f2;
                        border-radius: 5px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
                    }

                    h2 {
                        text-align: center;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Login Successful</h2>
                    <p>Welcome, ' . $username . '! You have successfully logged in.</p>
                </div>
            </body>
            </html>';
    // Redirect to customer dashboard or any other desired page
    header("Location: customer_dashboard.php");
} else {
    // Login failed
    echo '<!DOCTYPE html>
            <html>
            <head>
                <title>Login Failed</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 20px;
                        font-size: 18px;
                    }

                    .container {
                        max-width: 400px;
                        margin: 0 auto;
                        padding: 50px;
                        background-color: #f2f2f2;
                        border-radius: 5px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
                    }

                    h2 {
                        text-align: center;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h2>Login Failed</h2>
                    <p>Invalid username or password. Please try again.</p>
                </div>
            </body>
            </html>';
}

$conn->close();
?>
